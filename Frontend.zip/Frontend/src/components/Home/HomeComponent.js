import React, { Component } from 'react'
import SliderComponent from '../Slider/SliderComponent';
import { Carousel } from 'react-bootstrap'
import FooterComponent from '../Footer/FooterComponent';
import { Link } from "react-router-dom";
import HomeService from '../../services/Home/HomeService';
class HomeComponent extends Component{
    constructor(props){
        super(props)
        this.state={

        }
       this.login=this.login.bind(this);
       this.signup=this.signup.bind(this);
       this.home=this.home.bind(this);
    }
    login(){
        this.props.history.push('/login');
    }
    signup(){
        this.props.history.push('/signup');
    }
    home(){
        this.props.history.push('/home');
    }
    render(){
        return(
            <div className="home">
                
                  {/* <h2 className="text-center">The Workout Zone</h2> */}
                  {/* <button className="success" style={{width:'100px'}} onClick={() => this.login()}>Login</button>
                 <br/>
                 <button className="success" style={{width:'100px'}} onClick={() => this.signup()}>Signup</button>
                 <br/> */}
                <footer class="container-fluid bg-dark my-0 py-3 text-light">
                <br></br>
                <br></br>
                <div class="container col-sm-30 mt-30 ">
                    <p class="mb-5 ">
                    <Link to="/home">Home |</Link>
                    <Link to="/login">Login Here |</Link>
                    <Link to="/signup">Register Here</Link>
                    </p>
                </div>
                </footer> 
                 <SliderComponent /> 
             
            {/* <FooterComponent/> */}
            </div>

        )
    }
}
export default HomeComponent;