import React from "react";
import { UncontrolledCarousel } from "reactstrap";

//import img from Images/images.jpg

const items = [
  {
    src: "https://sporttechie-prod.s3.amazonaws.com/2017/06/shutterstock_366605333.jpg",
    altText: "Slide 1",
    header: "Vision Fitness club",
    caption: "HUSTLE FOR THAT MUSCLE",
    key: "1",
  },
  
  {
    src: "https://sporttechie-prod.s3.amazonaws.com/2017/06/shutterstock_366605333.jpg",
    altText: "Slide 2",
    header: "Vision Fitness club",
    caption: "HUSTLE FOR THAT MUSCLE",
    key: "2",
  },
  {
    src: "https://sporttechie-prod.s3.amazonaws.com/2017/06/shutterstock_366605333.jpg",
    altText: "Slide 3",
    header: "Vision Fitness club",
    caption: "HUSTLE FOR THAT MUSCLE",
    key: "3",
  },
];

const SliderComponent = () => <UncontrolledCarousel items={items} />;

export default SliderComponent;
