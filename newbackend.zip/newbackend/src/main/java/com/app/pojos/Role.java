package com.app.pojos;

public enum Role {
	ADMIN, MEMBER, TRAINER
}
